module com.example.pbo2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.pbo2 to javafx.fxml;
    exports com.example.pbo2;
    exports com.example.pbo2.model;
    opens com.example.pbo2.model to javafx.fxml;
    exports com.example.pbo2.controller;
    opens com.example.pbo2.controller to javafx.fxml;
}