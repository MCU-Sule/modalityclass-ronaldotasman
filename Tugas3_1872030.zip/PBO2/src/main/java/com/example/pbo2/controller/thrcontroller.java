package com.example.pbo2.controller;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class thrcontroller {
    public TextField iptmbhdiskon;
    public Button btntambahdiskon;

    int tambahdiskon;
    public void adddiskon(ActionEvent actionEvent) {
        tambahdiskon = Integer.parseInt(iptmbhdiskon.getText());
    }
}
