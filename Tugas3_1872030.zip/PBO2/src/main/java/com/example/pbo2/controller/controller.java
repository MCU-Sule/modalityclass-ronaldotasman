package com.example.pbo2.controller;

import com.example.pbo2.hello;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

public class controller {

    public Button btnaddmenu;
    public Button btndeletemenu;
    public ListView listview1;

    private Stage newstage;

    public void initialize(){
        newstage = new Stage();
        newstage.initModality(Modality.APPLICATION_MODAL);
    }

    public void addmenu(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(hello.class.getResource("seclayout.fxml"));
        Scene newscene = new Scene(loader.load());

        newstage.setScene(newscene);
        newstage.setTitle("Hello youre in the stage");
        newstage.show();
    }

    public void deletemenu(ActionEvent actionEvent) {
        int selected = listview1.getSelectionModel().getSelectedIndex();
        listview1.getItems().remove(selected);
    }
}