package com.example.pbo2.controller;

import com.example.pbo2.hello;
import com.example.pbo2.model.diskon;
import com.example.pbo2.model.menu;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;

public class seccontroller {

    public TextField nama;
    public TextField harga;
    public ComboBox cmb1;
    public Button btncustom;
    public Button btnaddmenusec;

    String datanama;
    int dataharga;

    public void submit(ActionEvent actionEvent){
        datanama = nama.getText();
        dataharga = Integer.parseInt(harga.getText());
    }

    public void addcustom(ActionEvent actionEvent) throws IOException {
        Stage newstage = new Stage();
        FXMLLoader loader = new FXMLLoader(hello.class.getResource("thrlayout.fxml"));
        Scene newscene = new Scene(loader.load());

        newstage.setScene(newscene);
        newstage.setTitle("Hello youre in the stage");
        newstage.show();
    }

    public void addmenusec(ActionEvent actionEvent) {

    }

    public void setdiskon(ActionEvent actionEvent) {
        ObservableList<diskon> dlist = FXCollections.observableArrayList(
                new diskon(10),
                new diskon(20),
                new diskon(30),
                new diskon(40),
                new diskon(50),
                new diskon(60),
                new diskon(70),
                new diskon(80),
                new diskon(90),
                new diskon(100)
        );

        cmb1.setItems(dlist);
        cmb1.getSelectionModel().select(0);
    }
}
