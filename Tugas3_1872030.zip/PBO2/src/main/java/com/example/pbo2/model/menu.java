package com.example.pbo2.model;

public class menu {
    private int hargamakan;
    private String namamakan;
    private int hargadiskon;
    private int persendiskon;

    public menu(int hargamakan, String namamakan, int hargadiskon, int persendiskon) {
        this.hargamakan = hargamakan;
        this.namamakan = namamakan;
        this.hargadiskon = hargadiskon;
        this.persendiskon = persendiskon;
    }

    public int getHargamakan() {
        return hargamakan;
    }

    public void setHargamakan(int hargamakan) {
        this.hargamakan = hargamakan;
    }

    public String getNamamakan() {
        return namamakan;
    }

    public void setNamamakan(String namamakan) {
        this.namamakan = namamakan;
    }

    public int getHargadiskon() {
        return hargadiskon;
    }

    public void setHargadiskon(int hargadiskon) {
        this.hargadiskon = hargadiskon;
    }

    public int getPersendiskon() {
        return persendiskon;
    }

    public void setPersendiskon(int persendiskon) {
        this.persendiskon = persendiskon;
    }
}
