package com.example.pbo2.model;

public class diskon {
    private int persen;

    public diskon(int persen) {
        this.persen = persen;
    }

    public int getPersen() {
        return persen;
    }

    public void setPersen(int persen) {
        this.persen = persen;
    }
}
